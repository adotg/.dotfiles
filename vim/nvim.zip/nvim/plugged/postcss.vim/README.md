**Please note this was a work in progress and it's not full featured as of yet. Development has halted at this time.**

---

# PostCSS Syntax for Vim

## Installation

* **Manually** copy `postcss.vim` file into your `~/.vim/syntax/` directory
* **Vundle** you can add this line to your `~/.vimrc` file -> `Plugin 'stephenway/postcss.vim'` then run `:PluginInstall!` in vim.
