import { Attach } from '@chemzqm/neovim/lib/attach/attach';
import Plugin from './plugin';
import './util/extensions';
declare const _default: (opts: Attach, requestApi?: boolean) => Plugin;
export default _default;
