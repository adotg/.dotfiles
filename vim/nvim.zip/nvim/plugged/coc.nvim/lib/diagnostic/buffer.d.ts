import { Diagnostic, Event, Disposable } from 'vscode-languageserver-protocol';
import { DiagnosticConfig } from './manager';
export declare class DiagnosticBuffer implements Disposable {
    private config;
    private readonly srdId;
    private readonly signIds;
    private sequence;
    private readonly _onDidRefresh;
    readonly matchIds: Set<number>;
    diagnostics: ReadonlyArray<Diagnostic>;
    readonly onDidRefresh: Event<void>;
    readonly bufnr: number;
    readonly refresh: (diagnosticItems: ReadonlyArray<Diagnostic>) => void;
    constructor(bufnr: number, config: DiagnosticConfig);
    private _refresh;
    setLocationlist(diagnostics: ReadonlyArray<Diagnostic>, winid: number): void;
    private clearSigns;
    checkSigns(): Promise<void>;
    addSigns(diagnostics: ReadonlyArray<Diagnostic>): void;
    setDiagnosticInfo(bufnr: number, diagnostics: ReadonlyArray<Diagnostic>): void;
    private addDiagnosticVText;
    clearHighlight(): void;
    addHighlight(diagnostics: ReadonlyArray<Diagnostic>, winid: any): void;
    /**
     * Used on buffer unload
     *
     * @public
     * @returns {Promise<void>}
     */
    clear(): Promise<void>;
    dispose(): void;
    private readonly document;
    readonly uri: string | null;
    private readonly nvim;
}
