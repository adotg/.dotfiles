export declare function generateUuid(): string;
