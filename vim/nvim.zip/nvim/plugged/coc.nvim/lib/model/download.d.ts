import { DownloadOptions } from '../types';
/**
 * Download and extract tgz from url
 *
 * @param {string} url
 * @param {DownloadOptions} options contains dest folder and optional onProgress callback
 */
export default function download(url: string, options: DownloadOptions): Promise<void>;
