/// <reference types="node" />
import { Agent, RequestOptions } from 'http';
import { UrlWithStringQuery } from 'url';
export declare function getAgent(endpoint: UrlWithStringQuery): Agent;
/**
 * Fetch text from server
 */
export default function fetch(url: string, data?: string | {
    [key: string]: any;
}, options?: RequestOptions): Promise<string | {
    [key: string]: any;
}>;
