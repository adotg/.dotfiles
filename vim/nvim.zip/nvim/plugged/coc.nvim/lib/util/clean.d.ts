export default function (): Promise<void>;
