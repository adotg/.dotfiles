export declare function memorize<R extends (...args: any[]) => Promise<R>>(_target: any, key: string, descriptor: any): void;
