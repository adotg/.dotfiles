export declare function score(needle: any, haystack: any): number;
export declare function positions(needle: string, haystack: string): number[];
export declare function hasMatch(needle: any, haystack: any): boolean;
