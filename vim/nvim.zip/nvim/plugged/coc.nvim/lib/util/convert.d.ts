import { SymbolKind } from 'vscode-languageserver-protocol';
export declare function getSymbolKind(kind: SymbolKind): string;
